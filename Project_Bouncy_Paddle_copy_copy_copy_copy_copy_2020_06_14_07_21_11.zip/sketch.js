var ball,img,paddle,pimg;
function preload() {
img = loadAnimation("ball.png");
pimg = loadAnimation("paddle.png");
}
function setup() {
  createCanvas(400, 400);
  ball = createSprite(200,200,20,20);
  ball.addAnimation("ballanimation", img);
  paddle = createSprite(380,200,20,10);
  paddle.addAnimation("paddleanimation", pimg);

}

function draw() {
  edges = createEdgeSprites();
  ball.bounceOff(edges[0]);
  ball.bounceOff(edges[2]);
  ball.bounceOff(edges[3]);
  ball.bounceOff(paddle);


  background(205,153,0);
   
  
  paddle.y = World.mouseY;
  
  if(keyDown("space")) {
   ball.velocityX = 10;
    ball.velocityY = 10;
  }
  
  if(ball.x > 400) {
   ball.x = 200;
   ball.y = 200;
   ball.velocityX = 0;
  ball.velocityY = 0;
  }
  
  drawSprites();
  
}


